Here's a refactored version of the code using functional components with hooks:

```jsx
import React, { useState } from 'react';

const Welcome = () => {
  const [name, setName] = useState('Guest');

  return (
    <h1>Welcome, {name}!</h1>
  );
};

export default Welcome;
```

In this refactored version:
- The class component has been converted to a functional component.
- The state has been simplified to use the `useState` hook, which handles the `name` state.
- The `name` state can be updated using the `setName` function returned by the `useState` hook.