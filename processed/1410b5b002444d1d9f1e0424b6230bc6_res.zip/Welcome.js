```jsx
import React, { useState } from 'react';

const Welcome = () => {
  const [name, setName] = useState('Guest');

  return <WelcomeMessage name={name} setName={setName} />;
};

const WelcomeMessage = ({ name, setName }) => {
  return <h1>Welcome, {name}!</h1>;
};

export default Welcome;
```