```javascript
import React, { useState } from 'react';

const Welcome = () => {
  const [name, setName] = useState('Guest');

  return <h1>Welcome, {name}!</h1>;
}

export default Welcome;
```