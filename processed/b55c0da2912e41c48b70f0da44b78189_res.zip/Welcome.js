Here is a refactored version of the code using functional components with hooks:

```jsx
import React, { useState } from 'react';

const Welcome = () => {
  const [name, setName] = useState('Guest');

  return <h1>Welcome, {name}!</h1>;
};

export default Welcome;
```

In this refactored version:
- I converted the `Welcome` component from a class component to a functional component using the `useState` hook to manage the `name` state.
- I simplified the state to just a single `name` state variable using `useState`.
- The component now directly returns the JSX content without the need for a `render` method.